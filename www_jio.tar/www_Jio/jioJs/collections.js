"use strict";

var c_HELP_LOGS = Backbone.Collection.extend({
	url: '/data/help_logs.json',
	models: new m_HELP_LOG
});

var c_SETTINGS_CELLULAR_APNS = Backbone.Collection.extend({
	url: '/data/settings_cellular_apn.json',
	models: new m_SETTINGS_CELLULAR_APN
});

var c_CONNECTED_DEVICE = Backbone.Collection.extend({
	url: '/data/connected_device.json',
	models: new m_CONNECTED_DEVICE
});

var c_CDT_STATUS = Backbone.Collection.extend({
	url: '/data/cdt_status.json',
	models: new m_CDT_STATUS
});

var c_SETTINGS_LAN_IPV4_STATIC_ADDRESS_LISTS = Backbone.Collection.extend({
	url: '/data/settings_lan_ipv4_static_address.json',
	models: new m_SETTINGS_LAN_IPV4_STATIC_ADDRESS_LIST
});

var c_SETTINGS_DHCP_SERVER_LEASE_RESERVATION_LIST = Backbone.Collection.extend({
	url: '/data/settings_dhcp_server_lease_reservation_list.json',
	models: new m_SETTINGS_DHCP_SERVER_LEASE_RESERVATION_LIST
});

var c_MACADRRESS_FILTERS = Backbone.Collection.extend({		
	url: '/data/macaddr_filtering_list.json',
	models: new m_MACADRRESS_FILTER
});
var c_EOGRE_RULE_LIST = Backbone.Collection.extend({		
	url: '/data/eogre_rule_list.json',
	models: new m_EOGRE_RULE
});
var c_EOGRE_RULE_LIST2 = Backbone.Collection.extend({		
	url: '/data/eogre_rule_list2.json',
	models: new m_EOGRE_RULE2
});
var c_EOGRE_IPSEC_RULES_LIST = Backbone.Collection.extend({		
	url: '/data/eogre_ipsec_rules_list.json',
	models: new m_EOGRE_IPSEC_RULE
});
var c_IPSEC_RULE_LIST = Backbone.Collection.extend({		
	url: '/data/ipsec_rule_list.json',
	models: new m_IPSEC_RULE
});
var c_OPENVPN_RULE_LIST = Backbone.Collection.extend({		
	url: '/data/openvpn_rule_list.json',
	models: new m_OPENVPN_RULE
});
var c_URL_FILTERS = Backbone.Collection.extend({		
	url: '/data/url_filtering_list.json',
	models: new m_URL_FILTER
});
var c_IPADDR_FILTERS = Backbone.Collection.extend({		
	url: '/data/ipaddr_filtering_list.json',
	models: new m_IPADDR_FILTER
});
var c_LanIPV6_LEASE_RESERVATION_LIST = Backbone.Collection.extend({		
	url: '/data/lanipv6_lease_reservation_list.json',
	models: new m_LanIPV6_LEASE_RESERVATION
});
var c_ROUTING_TABLE = Backbone.Collection.extend({		
	url: '/data/routing_table.json',
	models: new m_ROUTING_TABLE
});

var c_SMS_INBOX = Backbone.Collection.extend({		
	url: '/data/sms_inbox.json',
	models: new m_SMS_INBOX
});
var c_SMS_SENT = Backbone.Collection.extend({		
	url: '/data/sms_sent.json',
	models: new m_SMS_SENT
});
var c_SMS_CONTACTS = Backbone.Collection.extend({		
	url: '/data/sms_contacts.json',
	models: new m_SMS_CONTACTS
});
var c_SMS_GROUPS = Backbone.Collection.extend({		
	url: '/data/sms_groups.json',
	models: new m_SMS_GROUPS
});
var c_ESIM_PROFILES = Backbone.Collection.extend({		
	url: '/data/settings_esim_profiles_list.json',
	models: new m_ESIM_PROFILE
});

var c_PORTFORWARDING_RULES = Backbone.Collection.extend({
	url: '/data/upnp_port_forwarding_rules.json',
	models: new m_PORTFORWARDING_RULE
});

var c_NETWORK_STATUS_NR_CA_SCELLS = Backbone.Collection.extend({
	url: '/data/network_status_nr_ca_scells.json',
	models: new m_NETWORK_STATUS_NR_CA_SCELLS
});

