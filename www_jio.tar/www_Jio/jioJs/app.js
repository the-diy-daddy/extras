"use strict";

var app = new PAGE_MAIN();
