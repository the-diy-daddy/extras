"use strict";

var app = new PAGE_LOGIN();
