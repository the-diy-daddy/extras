"use strict";

var app = new PAGE_UPDATE_PASSWORD();
